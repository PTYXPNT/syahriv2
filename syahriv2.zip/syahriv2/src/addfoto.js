const addfoto = () => { 
	return `
	
	*ADD DATABASE FOTO*
	
	FOTO BERHASIL DISIMPAN KE DATA!
	

Thanks !`
}
exports.addfoto = addfoto