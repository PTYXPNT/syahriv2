const cekvip = () => { 
	return `           
──────────────────
*Nama bot* :  𝐼𝐶𝐻𝐼 𝐵𝑂𝑇
──────────────────
        『 *𝐕𝐈𝐏 𝐔𝐒𝐄𝐑* 』
──────────────────
• *Status*    : *ACTIVE*
────────────────── 
*Status Bot:* *Online*
────────────────── `
}
exports.cekvip = cekvip